package pac.com.on;

//Create a class GovernmentRules with a final variable MAX_WORKING_HOURS = 8
//Try modifying it inside main and observe compile-time restriction.

class GovernmentRules{
	final int MAX_WORKING_HOURS=8;
	
	
}
public class FinalConstantPrg22 {

	public static void main(String[] args) {
		GovernmentRules g= new GovernmentRules();
		//g.MAX_WORKING_HOURS=9;

	}

}
