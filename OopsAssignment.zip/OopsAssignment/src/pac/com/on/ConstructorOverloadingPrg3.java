package pac.com.on;

//Create a class Product having instance variables productId, productName, and price.
//Implement:
//
//A default constructor that prints "Product Created".
//
//A parameterized constructor that initializes the product details.
//Write a method displayProduct() to print product details.
//Create both types of objects in the main method.

class Product {
	int productId;
	String productName;
	double price;
	
	 Product() {
		System.out.println("Product Created");
	}
	
	Product(int a, String b, double c) {
		productId = a;
		productName = b;
		price = c;
		
		}
	void displayProduct() {
		System.out.println("Product ID"+" "+ productId);
		System.out.println("Product Name"+" "+ productName);
		System.out.println("Product Price"+" "+ price);
	}
}

public class ConstructorOverloadingPrg3 {

	public static void main(String[] args) {
		Product p1= new Product();
		Product p2= new Product(12,"phone",20000.9);
		p2.displayProduct();
		

	}

}
