package pac.com.on;

//Create a class Camera with a method capture().
//Create a subclass DSLCamera that overrides the method.
//Use parent reference to call child object method (dynamic polymorphism).

class Camera{
	void capture() {
		System.out.println("The picture has captured");
	}
}

class DSLCamera extends Camera{
	void capture() {
		
		System.out.println("The picture has captured with better clarity");
	}
}

public class PolymorphismProgram19 {

	public static void main(String[] args) {
		Camera obj = new DSLCamera();
		obj.capture();
	}

}
