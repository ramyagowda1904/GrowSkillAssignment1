package pac.com.on;

//Create an interface Transport with method booking().
//Implement it in Bus and Flight classes.
//Call using interface reference.

interface Transport{
	void booking();
}

class Bus implements Transport{
	public void booking() {
		System.out.println("Bus tickets booking are available");
	}
}

class Flight implements Transport{
	public void booking() {
		System.out.println("Flight tickets booking are available");
	}
}

public class InterfacewithMultiplePrg18 {

	public static void main(String[] args) {
	 Flight f= new Flight();
	 f.booking();
	 Bus b=new Bus();
	 b.booking();

	}

}
