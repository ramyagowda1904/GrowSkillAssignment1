package pac.com.on;

//Create a class Account with private variables accountHolderName and balance.
//Provide setters and getters, where:
//
//setBalance() should not accept negative values (print a warning).
//Create an object and update values through setters only.

class Account{
	private String accountHolderName;
	private double balance;
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		if(balance<0) {
			System.out.println("balance cannot be negative");
		}else {
			this.balance = balance;
		}
	}
	
	void showDetails() {
		System.out.println("Account Holder Name:"+" "+accountHolderName);
		System.out.println("Account Balance:"+" "+balance);
	}
}



public class EncapsulationValidPrg12 {

	public static void main(String[] args) {
		Account a1 = new Account();
		Account a2 = new Account();
		a1.setAccountHolderName("Tester");
		a1.setBalance(3000);
		a1.showDetails();
		
		a2.setAccountHolderName("Driver");
		a2.setBalance(-200);
		a2.showDetails();

	}

}
