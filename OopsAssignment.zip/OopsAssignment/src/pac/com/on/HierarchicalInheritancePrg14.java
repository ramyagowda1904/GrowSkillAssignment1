package pac.com.on;

//Create a class Course with a method courseInfo().
//Create subclasses Science, Commerce, and Arts each with their own method.
//Create objects of each and call methods to show hierarchy.

class Course{
	void courseInfo() {
		System.out.println("The following are couse available:");
	}
}

class Science extends Course{
	void science() {
		System.out.println("Science course are available");
	}
}

class Commerce extends Course{
	void commerce() {
		System.out.println("Commerce course are available");
	}
}

class Arts extends Course{
	void arts() {
		System.out.println("Arts course are available");
	}
}

public class HierarchicalInheritancePrg14 {

	public static void main(String[] args) {
		Science s = new Science();
		s.courseInfo();
		s.science();
		Commerce c = new Commerce();
		c.commerce();
		Arts a = new Arts();
		a.arts();
		
		

	}

}
