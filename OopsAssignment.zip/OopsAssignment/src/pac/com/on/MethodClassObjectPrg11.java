package pac.com.on;

//Create a class Library with an instance variable libraryName.
//Create a default constructor to print "Welcome to the Library!".
//Create a method showLocation() which prints "This library is located in Mumbai".
//Create an object in main() and call both.

class Library{
	String libraryName = "Centaral Library of Bombay";
	
	Library(){
		System.out.println("Welcome to the Library");
	}
	
	void showLibrary() {
		System.out.println("Library is located in Mumbai");
	}
}

public class MethodClassObjectPrg11 {

	public static void main(String[] args) {
		Library l= new Library();
		l.showLibrary();
		System.out.println("Library Name is "+ " "+l.libraryName);

	}

}
