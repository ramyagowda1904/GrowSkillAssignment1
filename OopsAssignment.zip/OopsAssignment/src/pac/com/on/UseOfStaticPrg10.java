package pac.com.on;


//Create a class Student having static variable collegeName and instance variables name and rollNo.
//Write a method to print both static and instance data.
//Create multiple objects to show static value remains constant.

class Student{
	static String collegeName="Delhi University";
	String studentName;
	long rollNo;
	
	void displaydata(String x, long y) {
		studentName=x;
		rollNo=y;
		System.out.println(collegeName+" "+studentName+" "+rollNo);
	}
}

public class UseOfStaticPrg10 {

	public static void main(String[] args) {
		Student s1= new Student();
		Student s2= new Student();
		Student s3= new Student();
		
		s1.displaydata("Raja", 1254698);
		s2.displaydata("Ram", 126546);
		s3.displaydata("Krish", 14523645);

	}

}
