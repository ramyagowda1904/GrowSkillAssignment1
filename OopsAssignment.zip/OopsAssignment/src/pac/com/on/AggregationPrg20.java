package pac.com.on;

//Create a class Engine with a method engineInfo().
//Create a class Car that has-a Engine object and uses it to show engine details.
//Show aggregation in main method.

class Engine{
	void engineInfo() {
		System.out.println("Enginee Information...");
	}
}

class Car{
	Engine eng;   // Aggregation

    // Constructor
    Car(Engine eng) {

        this.eng = eng;
    }

    void displayCarInfo() {

        System.out.println("Car details:");

        eng.engineInfo();
    }
}

public class AggregationPrg20 {

	public static void main(String[] args) {
		Engine e1 = new Engine();
        Car c1 = new Car(e1);
        c1.displayCarInfo();

	}

}
