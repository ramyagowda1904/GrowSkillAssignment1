package pac.com.on;

//Create a class Mall with:
//
//Default constructor printing "Welcome to the Mall"
//
//Parameterized constructor calling default constructor using this()
//Demonstrate constructor chaining in main.

class Mall{
	Mall(){
		System.out.println("Welcome to the Mall");
	}
	
	Mall(String shop){
		this();
		System.out.println("Shop"+" "+shop);
	}
	
}

public class ConstructorChainingPrg23 {

	public static void main(String[] args) {
		Mall m=new Mall("KFC");
		

	}

}
