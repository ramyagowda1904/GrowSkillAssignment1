package pac.com.on;

//Create an interface Payment with a method makePayment().
//Create two classes UPI and CreditCard implementing this interface and define their own payment messages.
//Call the method through interface reference.

interface Payment{
	void makePayment();
}

class UPI implements Payment{
	public void makePayment() {
		System.out.println("Payment successufully completed via through UPI");
	}
}

class creditCard implements Payment{
	public void makePayment() {
		System.out.println("Payment successufully completed via through credit card");
	}
}


public class ProgramInterface6 {

	public static void main(String[] args) {
		UPI ob=new UPI();
		creditCard oj=new creditCard();
		ob.makePayment();
		oj.makePayment();

	}

}
