package pac.com.on;

//Create a parent class Shape with a method area().
//Create subclasses Rectangle and Circle and override the area() method.
//Create a reference of Shape and assign objects of both subclasses one by one, calling area() each time.

class Shape{
	double area() {
		return 0;
	}
}
class Rectangle extends Shape{
	double area() {
		int l=5;
		int b=4;
		return l*b;
	}
}
class Circle extends Shape{
	double area() {
		int r=6;
		return 3.14*r*r;
	}
}


public class PolymorphismPrg8 {

	public static void main(String[] args) {
		Rectangle r = new Rectangle();
		Circle c= new Circle();
		
		System.out.println("Area of Rectangle is"+ " "+r.area());
		System.out.println("Area of Circle is"+ " "+c.area());
		
		

	}

}
