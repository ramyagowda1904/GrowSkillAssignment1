package pac.com.on;

//Create a class LoanCalculator with two overloaded methods:
//calculateLoan(int amount)
//calculateLoan(int amount, double interestRate)
//Print loan details accordingly. Call both methods from main.

class LoanCalculator{
	void calculatorLoan(int amount) {
		
		int n=2;
		double loan = amount/n;
		System.out.println("Loan is"+" "+loan);
		
	}
	void calculatorLoan(int amount, double interestRate) {
		
		int n=2;
		double r=Math.pow((1+interestRate), n);
		double loan = (amount*interestRate*r)/(r-1);
		System.out.println("Loan is"+" "+loan);
				
	}
}

public class MethodOverloadingProg15 {

	public static void main(String[] args) {
		LoanCalculator L1 = new LoanCalculator();
		L1.calculatorLoan(4000);
		LoanCalculator L2 = new LoanCalculator();
		L2.calculatorLoan(4000,2.6);
		

	}

}
