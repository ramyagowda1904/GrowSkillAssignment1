package pac.com.on;
//create a class named school 
//create name, address,strength as their instance variables 
//Create two constructor one with two variables and one with all the three variables 
//Create a method that will display all the three parameters 
//create two object of this class and call the respective methods 

class school{
	String address;
	String name;
	int strenght;
	
	school(String a, String b){
		address =a;
		name=b;
	}
	
	school(String a,String b,int c){
		address=a;
		name=b;
		strenght=c;
	}
	
	void display() {
		System.out.println(address+" "+name+" "+strenght);
	}
}

public class ConstructorChainingPrg26 {

	public static void main(String[] args) {
		school s1=new school();
		school s2=new school();
		s1.display("pune","GRU");
		s2.display("chennai","ASU",700);

	}

}
