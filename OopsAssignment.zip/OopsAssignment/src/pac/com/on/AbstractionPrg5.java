package pac.com.on;

//Create an abstract class Animal with an abstract method sound().
//Create two subclasses Dog and Cat and provide implementation for sound() method.
//Create objects and call sound() for each.

abstract class Animal{
	abstract void sound(); 
		
}

class Dog extends Animal{
	 void sound() {
		System.out.println("dog making sound");
	}
}

class Cat extends Animal{
	void sound() {
		System.out.println("Cat making sound");
	}
}

public class AbstractionPrg5 {

	public static void main(String[] args) {
		Dog d = new Dog();
		Cat c = new Cat();
		d.sound();
		c.sound();

	}

}
