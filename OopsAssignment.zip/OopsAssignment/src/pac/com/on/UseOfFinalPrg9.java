package pac.com.on;

//Create a class Bank with a final variable IFSC and final method showIFSC().
//Try creating a subclass HDFCBank and attempt overriding the final method (should show compile-time restriction).
//Create a main method to demonstrate usage.

class Bank{
	final String type = "IFSC";
	
	final void showIFSC() {
		System.out.println("The bank is IFSC");
	}
}
	
class HDFCBank extends Bank{
	/*
	 * void showIFSC() { System.out.println("The bank is HDFC"); }
	 */
}
	


public class UseOfFinalPrg9 {

	public static void main(String[] args) {
		HDFCBank b= new HDFCBank();
		b.showIFSC();
		
	}

}
