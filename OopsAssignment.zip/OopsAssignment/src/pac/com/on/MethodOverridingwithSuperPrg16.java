package pac.com.on;

//Create a base class Hospital with a method emergencyService().
//Create a subclass CityHospital that overrides the method and calls parent method using super.emergencyService().
//Demonstrate overriding in main.

class Hospital{
	void emergencyService(){
		System.out.println("Surgeries are done");
	}
}

class CityHospital extends Hospital{
	void emergencyService() {
		super.emergencyService();
		System.out.println("Luxury facalities are provided");
	}
}

public class MethodOverridingwithSuperPrg16 {

	public static void main(String[] args) {
		CityHospital C=new CityHospital();
		C.emergencyService();

	}

}
