package pac.com.on;

//Create three classes:
//Device → method start()
//Mobile extends Device → method calling()
//SmartPhone extends Mobile → method internet()
//Create object of SmartPhone and call all methods.

class Device{
	void start() {
		System.out.println("Device is getting started");
	}
}
class Mobile extends Device{
	void calling() {
		System.out.println("Mobile is connecting to a call");
	}
}
class SmartPhone extends Mobile{
	void internet() {
		System.out.println("Internet is accessible on SmartPhone");
	}
}

public class MultilevelInheritancePrg13 {

	public static void main(String[] args) {
		SmartPhone s= new SmartPhone();
		s.start();
		s.calling();
		s.internet();

	}

}
