package pac.com.on;

//Create a class Calculator with overloaded methods add():
//
//add(int a, int b)
//
//add(double a, double b)
//Call both methods inside the main method and print results.


class Calculator{
	void add(int a, int b) {
		int c = a+b;
		System.out.println("sum"+" "+ c);
	}
	
	void add(double a, double b) {
		double c= a+b;
		System.out.println("sum"+" "+c);
	}
	
}

public class MethodOverloadingPrg4 {

	public static void main(String[] args) {
		Calculator c1= new Calculator();
		c1.add(67, 35);
		c1.add(85.2, 23.6);


	}

}
