package pac.com.on;

//Create a Class named Shape with length as instance variable  , create three methods as square , rectangle , circle 
//and find out their respective areas 
//Create a object in main method and call these different methods with the instance of object 

class Shape{
    int length = 5;

    void square() {
        int area = length * length;
        System.out.println("Area of Square: " + area);
    }

    void rectangle() {
        int breadth = 4;
        int area = length * breadth;
        System.out.println("Area of Rectangle: " + area);
    }
   
    void circle() {
        double area = 3.14 * length * length;
        System.out.println("Area of Circle: " + area);
    }
}

public class ConstructorChainingPrg24 {

	public static void main(String[] args) {
		Shape s = new Shape();
        s.square();
        s.rectangle();
        s.circle();

	}

}
