package pac.com.on;

//Create an abstract class Employee with:
//abstract method: calculateSalary()
//concrete method: employeeDetails()
//Subclass FullTimeEmployee and PartTimeEmployee implementing salary calculation logic differently.

abstract class Employee{
	abstract void calculateSalary();
	
	void emploeeDetails() {
		
		System.out.println("Employee details are listed");
	}
}

class FullTimeEmployee extends Employee{
	void calculateSalary() {
		double salary=30000.4;
		System.out.println("Full time Employee Salary is"+" "+salary);
	}
}

class PartTimeEmployee extends Employee{
	void calculateSalary() {
		int hoursWorked = 40;
        int salaryPerHour = 400;

        int salary = hoursWorked * salaryPerHour;

        System.out.println("Part-time Employee Salary: " + salary);
	}
}


public class AbstractRealPro17 {

	public static void main(String[] args) {
		FullTimeEmployee f = new FullTimeEmployee();

      
        f.calculateSalary();

        PartTimeEmployee p = new PartTimeEmployee();

      
        p.calculateSalary();

	}

}
