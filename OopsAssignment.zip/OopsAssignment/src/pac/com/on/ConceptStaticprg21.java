package pac.com.on;

//Create a class University with:
//static variable country = "India"
//instance variable universityName
//Print values using different objects to show static effect.

class University{
	static String country="India";
	String universityName;
	
	University(String universityName){
		this.universityName=universityName;
	}
}
public class ConceptStaticprg21 {
	public static void main(String[]argu) {
		University u1=new University("Delhi University");
		System.out.println(u1.country+" "+"has the"+" "+u1.universityName);
		University u2=new University("Mumbai University");
		System.out.println(u2.country+" "+"has the"+" "+u2.universityName);
	}

}
